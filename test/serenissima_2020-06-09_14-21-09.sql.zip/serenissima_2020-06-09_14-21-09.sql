-- MySQL dump 10.17  Distrib 10.3.17-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: serenissima
-- ------------------------------------------------------
-- Server version	5.7.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agente`
--

DROP TABLE IF EXISTS `agente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agente` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agente` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Id_2` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agente`
--

LOCK TABLES `agente` WRITE;
/*!40000 ALTER TABLE `agente` DISABLE KEYS */;
INSERT INTO `agente` VALUES (1,'marco genovese');
/*!40000 ALTER TABLE `agente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `amministratore`
--

DROP TABLE IF EXISTS `amministratore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `amministratore` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `utente` varchar(150) NOT NULL DEFAULT '',
  `password` varchar(150) NOT NULL DEFAULT '',
  `utentetipo` varchar(150) NOT NULL DEFAULT '',
  `nome` varchar(250) NOT NULL DEFAULT '',
  `cognome` varchar(250) NOT NULL DEFAULT '',
  `telefono` varchar(250) NOT NULL DEFAULT '',
  `email` varchar(250) NOT NULL DEFAULT '',
  `sede` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amministratore`
--

LOCK TABLES `amministratore` WRITE;
/*!40000 ALTER TABLE `amministratore` DISABLE KEYS */;
INSERT INTO `amministratore` VALUES (1,'marco','genovese','Amministratore','marco','genovese','3920426808','jeniuscommunications@gmail.com','treviso');
/*!40000 ALTER TABLE `amministratore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appuntamenti`
--

DROP TABLE IF EXISTS `appuntamenti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appuntamenti` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `data` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `operazione` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `idcontatto` bigint(20) unsigned NOT NULL DEFAULT '0',
  `nominativo` varchar(250) DEFAULT NULL,
  `titolo` varchar(250) DEFAULT NULL,
  `note` text,
  `tipoappuntamento` varchar(250) DEFAULT NULL,
  `telefono` varchar(250) DEFAULT NULL,
  `mobile` varchar(250) DEFAULT NULL,
  `mail` varchar(250) DEFAULT NULL,
  `esito` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appuntamenti`
--

LOCK TABLES `appuntamenti` WRITE;
/*!40000 ALTER TABLE `appuntamenti` DISABLE KEYS */;
/*!40000 ALTER TABLE `appuntamenti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorie` (
  `idcategoriacliente` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `categoriacliente` varchar(250) DEFAULT NULL,
  UNIQUE KEY `Idcategoriacliente` (`idcategoriacliente`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorie`
--

LOCK TABLES `categorie` WRITE;
/*!40000 ALTER TABLE `categorie` DISABLE KEYS */;
INSERT INTO `categorie` VALUES (4,'1) MLNV'),(24,'2) CLNV');
/*!40000 ALTER TABLE `categorie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contatti`
--

DROP TABLE IF EXISTS `contatti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contatti` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL DEFAULT '',
  `cognome` varchar(150) NOT NULL DEFAULT '',
  `indirizzo` varchar(150) NOT NULL DEFAULT '',
  `citta` varchar(150) NOT NULL DEFAULT '',
  `provincia` varchar(150) NOT NULL DEFAULT '',
  `telefono` varchar(150) NOT NULL DEFAULT '',
  `fax` varchar(150) NOT NULL DEFAULT '',
  `cellulare` varchar(150) NOT NULL DEFAULT '',
  `mail` varchar(150) NOT NULL DEFAULT '',
  `note` mediumtext NOT NULL,
  `data` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=143 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contatti`
--

LOCK TABLES `contatti` WRITE;
/*!40000 ALTER TABLE `contatti` DISABLE KEYS */;
INSERT INTO `contatti` VALUES (116,'Marco','Genovese','via europa 108','giavera del montello','TREVISO','3663619529','','','direzione@costruttori.it','test','2020-02-20 00:00:00'),(117,'','iscri.newsletter','','','','','','','jeniuscommunications@gmail.com','','2020-02-20 00:00:00'),(118,'Marco','Genovese','via europa 108','giavera del montello','TREVISO','3663619529','','','jeniuscommunications@gmail.com','','2020-02-20 00:00:00'),(119,'','iscri.newsletter','','','','','','','jeniuscommunications@gmail.com','','2020-02-20 00:00:00'),(120,'','iscri.newsletter','','','','','','','JENIUSCOMMUNICATIONS@GMAIL.COM','','2020-02-20 00:00:00'),(121,'','iscri.newsletter','','','','','','','jeniuscommunications@gmail.com','','2020-02-26 00:00:00'),(122,'','iscri.newsletter','','','','','','','fonte1987@hotmail.it','','2020-03-02 00:00:00'),(123,'gino','prova','VIA SENATORE FABBRI 60','LOVADINA','----------SELEZIONA----------','0422880820','','','fonte1987@hotmail.it','ciao','2020-03-02 00:00:00'),(124,'gino','prova','VIA SENATORE FABBRI 60','LOVADINA','----------SELEZIONA----------','0422880820','','','fonte1987@hotmail.it','ciao','2020-03-02 00:00:00'),(125,'','iscri.newsletter','','','','','','','maverick_t8@outlook.it','','2020-03-03 00:00:00'),(126,'','iscri.newsletter','','','','','','','partelvittorio@gmail.com','','2020-03-05 00:00:00'),(127,'','iscri.newsletter','','','','','','','renatodeconto8@gmail.com','','2020-03-08 00:00:00'),(128,'Franco','Pistoia','Via Fant 5','Santa Giustina ','BELLUNO','3356945611','','','Pistoia.franco@gmail.com','Attualmente membro ANV - clnv','2020-03-09 00:00:00'),(129,'','iscri.newsletter','','','','','','','robertomarcianokira57@gmail.com','','2020-03-09 00:00:00'),(130,'','iscri.newsletter','','','','','','','alforcelletto@gmail.com','','2020-03-10 00:00:00'),(131,'','iscri.newsletter','','','','','','','renatodeconto8@gmail.com','','2020-03-12 00:00:00'),(132,'','iscri.newsletter','','','','','','','partelvittorio@gmail.com','','2020-03-12 00:00:00'),(133,'','iscri.newsletter','','','','','','','guerrinoferronato@gmail.com','','2020-03-15 00:00:00'),(134,'','iscri.newsletter','','','','','','','francemarchesini93@gmail.com','','2020-03-16 00:00:00'),(135,'','iscri.newsletter','','','','','','','ferrosmarco@gmail.com','','2020-03-21 00:00:00'),(136,'','iscri.newsletter','','','','','','','meneghesso@gmail','','2020-03-25 00:00:00'),(137,'','iscri.newsletter','','','','','','','aldo.sassi@yahoo.it','','2020-03-27 00:00:00'),(138,'Ferruccio','Lorenzutti','via Marino Falier','Chioggia','VENEZIA','3343388752','','','f.lorenzutti@virgilio.it','','2020-03-30 00:00:00'),(139,'','iscri.newsletter','','','','','','','f.lorenzutti@virgilio.it','','2020-03-30 00:00:00'),(140,'luigino','zorzetto','via casottinuovi 18','albaredo d`adige','VERONA','3476879745','','','4mediapromo@gmail.com','voria saver qualcoxa, se me mandè par la banca e par el made in veneto so interesà.','2020-04-02 00:00:00'),(141,'','iscri.newsletter','','','','','','','prf.sergio.32@gmail.com','','2020-05-12 00:00:00'),(142,'','iscri.newsletter','','','','','','','pieromaset@gmail.com','','2020-05-27 00:00:00');
/*!40000 ALTER TABLE `contatti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pratiche`
--

DROP TABLE IF EXISTS `pratiche`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pratiche` (
  `idpratica` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `idregistrazione1` bigint(20) unsigned NOT NULL DEFAULT '0',
  `nominativo` varchar(250) NOT NULL DEFAULT '',
  `mobile` varchar(250) DEFAULT NULL,
  `mail` varchar(250) DEFAULT NULL,
  `provincia` varchar(250) DEFAULT NULL,
  `dati` tinyint(1) NOT NULL DEFAULT '0',
  `esitibanca` tinyint(1) NOT NULL DEFAULT '0',
  `allegati` tinyint(1) NOT NULL DEFAULT '0',
  `inviopratica` tinyint(1) NOT NULL DEFAULT '0',
  `data` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`idpratica`,`nominativo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pratiche`
--

LOCK TABLES `pratiche` WRITE;
/*!40000 ALTER TABLE `pratiche` DISABLE KEYS */;
/*!40000 ALTER TABLE `pratiche` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registrazione1`
--

DROP TABLE IF EXISTS `registrazione1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registrazione1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(250) NOT NULL DEFAULT '',
  `cognome` varchar(250) NOT NULL DEFAULT '',
  `indirizzo` varchar(250) DEFAULT NULL,
  `citta` varchar(250) DEFAULT NULL,
  `cap` varchar(255) DEFAULT NULL,
  `provincia` varchar(250) NOT NULL DEFAULT '',
  `email` varchar(250) DEFAULT NULL,
  `telefono` varchar(250) DEFAULT NULL,
  `pi` varchar(250) DEFAULT NULL,
  `cf` varchar(250) DEFAULT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ragione` varchar(255) NOT NULL DEFAULT '',
  `sede` varchar(255) DEFAULT NULL,
  `utente1` varchar(255) DEFAULT NULL,
  `password1` varchar(255) DEFAULT NULL,
  `password2` varchar(255) DEFAULT NULL,
  `frequenza` bigint(20) unsigned DEFAULT NULL,
  `nomeagente` varchar(250) DEFAULT NULL,
  `telefonoagente` varchar(50) DEFAULT NULL,
  `categoriacliente` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`,`provincia`,`ragione`,`cognome`),
  UNIQUE KEY `Utente1` (`utente1`) USING BTREE,
  UNIQUE KEY `Password1` (`password1`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrazione1`
--

LOCK TABLES `registrazione1` WRITE;
/*!40000 ALTER TABLE `registrazione1` DISABLE KEYS */;
INSERT INTO `registrazione1` VALUES (129,'Antonio','Meneghetti','Via Mortisia','Sant`Urbano','35040','PADOVA','maverick_t8@outlook.it','3339998843','','mngntn59c12z103v','2020-03-02 23:00:00','','Via Mortisia','Anton59','129_int','SeREnAVenetHIA1866',3,NULL,NULL,NULL),(123,'Valter','Michelini','Stradella Campagnavecchia,533','Fratta polesine','45025','ROVIGO','Info@valtermichelini.com','3703120529','','MCHVTR65B10H620G','2020-02-21 23:00:00','','Stradella Campagnavecchia,533','Sgheps44','123_int','Valter44',1,NULL,NULL,NULL),(132,'nicola','marin','Francesco Petrarca','San Dona` di Piave','30027','VENEZIA','nicola.marin@hotmail.com','3495065992','','MRNNCL83S25H823M','2020-03-03 23:00:00','','Francesco Petrarca','Niko Basta','132_int','CurvaSud1994',6,NULL,NULL,NULL),(133,'umberto','guariento','via A.Sartori Borotto,21/8','este','35042','PADOVA','umbertoguariento@yahoo.it','3488552575','','GRNMRT53R09442B','2020-03-04 23:00:00','','via A.Sartori Borotto,21/8','umberto953','133_int','hombreveneto@953',1,NULL,NULL,NULL),(134,'Irene','Barban','Via Castello 37','Torri di Quartesolo','36040','VICENZA','barban1971@virgilio.it','3285999481','02845930243','BRBRNI71S52L840H','2020-03-04 23:00:00','','Via Castello 37','Barbanirene','134_int','camilla',2,NULL,NULL,NULL),(135,'Mauro','Pol','via callalta 56','farra di soligo','31010','TREVISO','maurovento67@gmail.com','3409940t81','','PLOMRA46D29C957F','2020-03-04 23:00:00','','via callalta 56','MAU','135_int','antonio',1,NULL,NULL,NULL),(137,'Luca','De Toni','Via san Gregorio Barbarigo 8','Mestrino','35035','PADOVA','Hellspawn1@libero.it','3474888140','','Dtnlcu82b16g224l','2020-03-07 23:00:00','','Via san Gregorio Barbarigo 8','Hellspawn1','137_int','Stubbymp5',2,NULL,NULL,NULL),(138,'roberto ','Cavasin ','Via barche 47','Pederobba ','31040','TREVISO','Robertokira57@gmail.com','3337240067','','Cvsrrt57p15b349w','2020-03-08 23:00:00','','Via barche 47','Robertokira57@gmail .com','138_int','Comequando',1,NULL,NULL,NULL),(139,'Roberto ','Cavasin ','Via barche 47 ','Pederobba','31040','TREVISO','Alforcelletto@gmail.com','3336240067','','Cvsrrt57p15b349w','2020-03-09 23:00:00','','Via barche 47 ','Robertomarciano','139_int','Comewuando',1,NULL,NULL,NULL),(141,'marina','piccinato','via Amanti, 15','Verona','37121','VERONA','marina.piccinato@yahoo.it','3889250929','','PCCMRN51R57L781T','2020-03-11 23:00:00','','via Amanti, 15','maripicci','141_int','telescopioelettronico',9,NULL,NULL,NULL),(142,'Stefania','Citron','via Trento,20','Cordignano','31016','TREVISO','stefaniacitron73@gmail.com','3383415316','','CTRSFN73T64M089L','2020-03-13 23:00:00','','via Trento,20','Stefy73','142_int','veneto1866',1,NULL,NULL,NULL),(144,'Francesco ','Marchesini ','Loc Palù n2   Calmasino ','Bardolino Verona ','37011','VERONA','francemarchesini93@gmail.com','3286599176','','MRCFNC69B17B296J','2020-03-15 23:00:00','','Loc Palù n2   Calmasino ','Francemarchrsini','144_int','Diapason69',1,NULL,NULL,NULL),(146,'Carlo','Zanotelli','Via Venal, 40','Alpago','32016','BELLUNO','carlo.1974.zanotelli@gmail.com','3279727842','','ZNTCRL74P12A757K','2020-03-16 23:00:00','','Via Venal, 40','carlo.1974.zanotelli@gmail.com','146_int','Curach',1,NULL,NULL,NULL),(148,'marco','ferraresi','piazza carab a.ferro','volto di rosolina','45010','ROVIGO','ferrosmarco@gmail.com','3477236005','','FRRMRC67L19L359W','2020-03-20 23:00:00','','piazza carab a.ferro','EL MARCO','148_int','GranLeon69',2,NULL,NULL,NULL),(149,'Giancarlo','Modena','Borgo San Lorenzo 19/A','Costermano Sul Garda','37010','VERONA','modena.giancarlo@gmail.com','334 9099978','','MDNGCR62M02B296J','2020-03-20 23:00:00','','Borgo San Lorenzo 19/A','Modena Giancarlo','149_int','Mogano1963',3,NULL,NULL,NULL),(151,'Ricciardi','Frederic','Cannaregio 4016','Venezia ','Ve','VENEZIA','ricciardifrederic68@gmail.com','3482660950','','Rccfdr79h22z103u','2020-03-21 23:00:00','','Cannaregio 4016','VENEZIA4016','151_int','pepafred69328',1,NULL,NULL,NULL),(158,'Ermes','Zandi','Via fermi 12','Due Carrare ','35020','PADOVA','zandiermes@gmail.com','3284851893','','Zndrms71l29b833p','2020-03-29 22:00:00','','Via fermi 12','Ermes71','158_int','Ettore2013',1,NULL,NULL,NULL),(159,'Manolo ','Pozzo','Via canoro 4','Castelnuovo del garda','37014','VERONA','Mano2002it@yahoo.it','3935370066','','Pzzmnl73h24b296q','2020-03-30 22:00:00','','Via canoro 4','Manolo 73','159_int','53221820',1,NULL,NULL,NULL),(160,'Manuel ','Vignaga ','Via bassano 6','Jesolo','30016','VENEZIA','Manuel22788@hotmail.it','3407098223','','Vgnmnl88l22h923w','2020-04-06 22:00:00','','Via bassano 6','Manu22788','160_int','Mm22071988',2,NULL,NULL,NULL),(161,'Michele ','Giugni ','Sottomarina 1133','Chioggia ','30015','VENEZIA','Giuniulk@gmail.com','+393772227343','','Ggnmhl75c08c638k','2020-04-17 22:00:00','','Sottomarina 1133','Giuniulk','161_int','Giuni2020',1,NULL,NULL,NULL),(162,'Valentino ','Zonta ','Vicolo portile 3','Cassola','36022','VICENZA','valzon61.zv@gmail.com','3356369669','','ZNTVNT61L22A703F','2020-05-26 22:00:00','','Vicolo portile 3','Tino','162_int','SnAbi227',1,NULL,NULL,NULL),(164,'Flavio','Ferrari','Via bocca 90 d','Castelgomberto ','36070','VICENZA','gecoresine@gmail.com','3473735107','','FrrFlv53no42103n','2020-05-30 22:00:00','','Via bocca 90 d','Ferrari flavio','164_int','Qwertyuio1',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `registrazione1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registrazione2`
--

DROP TABLE IF EXISTS `registrazione2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registrazione2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(250) NOT NULL DEFAULT '',
  `cognome` varchar(250) NOT NULL DEFAULT '',
  `indirizzo` varchar(250) DEFAULT NULL,
  `citta` varchar(250) DEFAULT NULL,
  `cap` varchar(255) DEFAULT NULL,
  `provincia` varchar(250) NOT NULL DEFAULT '',
  `email` varchar(250) DEFAULT NULL,
  `telefono` varchar(250) DEFAULT NULL,
  `pi` varchar(250) DEFAULT NULL,
  `cf` varchar(250) DEFAULT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ragione` varchar(255) NOT NULL DEFAULT '',
  `sede` varchar(255) DEFAULT NULL,
  `utente1` varchar(255) DEFAULT NULL,
  `password1` varchar(255) DEFAULT NULL,
  `password2` varchar(255) DEFAULT NULL,
  `frequenza` bigint(20) unsigned DEFAULT NULL,
  `nomeagente` varchar(250) DEFAULT NULL,
  `telefonoagente` varchar(50) DEFAULT NULL,
  `categoriacliente` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`,`provincia`,`ragione`,`cognome`),
  UNIQUE KEY `Utente1` (`utente1`) USING BTREE,
  UNIQUE KEY `Password1` (`password1`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrazione2`
--

LOCK TABLES `registrazione2` WRITE;
/*!40000 ALTER TABLE `registrazione2` DISABLE KEYS */;
/*!40000 ALTER TABLE `registrazione2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registrazione3`
--

DROP TABLE IF EXISTS `registrazione3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registrazione3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(250) NOT NULL DEFAULT '',
  `cognome` varchar(250) NOT NULL DEFAULT '',
  `indirizzo` varchar(250) DEFAULT NULL,
  `citta` varchar(250) DEFAULT NULL,
  `cap` varchar(255) DEFAULT NULL,
  `provincia` varchar(250) NOT NULL DEFAULT '',
  `email` varchar(250) DEFAULT NULL,
  `telefono` varchar(250) DEFAULT NULL,
  `pi` varchar(250) DEFAULT NULL,
  `cf` varchar(250) DEFAULT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ragione` varchar(255) NOT NULL DEFAULT '',
  `sede` varchar(255) DEFAULT NULL,
  `utente1` varchar(255) DEFAULT NULL,
  `password1` varchar(255) DEFAULT NULL,
  `password2` varchar(255) DEFAULT NULL,
  `frequenza` bigint(20) unsigned DEFAULT NULL,
  `nomeagente` varchar(250) DEFAULT NULL,
  `telefonoagente` varchar(50) DEFAULT NULL,
  `categoriacliente` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`,`provincia`,`ragione`,`cognome`),
  UNIQUE KEY `Utente1` (`utente1`) USING BTREE,
  UNIQUE KEY `Password1` (`password1`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrazione3`
--

LOCK TABLES `registrazione3` WRITE;
/*!40000 ALTER TABLE `registrazione3` DISABLE KEYS */;
/*!40000 ALTER TABLE `registrazione3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sicurezzatcpip`
--

DROP TABLE IF EXISTS `sicurezzatcpip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sicurezzatcpip` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `codicetcpip` varchar(100) NOT NULL DEFAULT '',
  UNIQUE KEY `Id` (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sicurezzatcpip`
--

LOCK TABLES `sicurezzatcpip` WRITE;
/*!40000 ALTER TABLE `sicurezzatcpip` DISABLE KEYS */;
/*!40000 ALTER TABLE `sicurezzatcpip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statschede`
--

DROP TABLE IF EXISTS `statschede`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statschede` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `data` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fornitore` varchar(196) NOT NULL DEFAULT '''',
  `codice` varchar(196) NOT NULL DEFAULT '''',
  `categoria` varchar(196) NOT NULL DEFAULT '',
  `descrizione` varchar(196) NOT NULL DEFAULT '''',
  `utente` varchar(196) NOT NULL DEFAULT '''',
  `password` varchar(196) NOT NULL DEFAULT '''',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2449417 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statschede`
--

LOCK TABLES `statschede` WRITE;
/*!40000 ALTER TABLE `statschede` DISABLE KEYS */;
/*!40000 ALTER TABLE `statschede` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utenticollegati`
--

DROP TABLE IF EXISTS `utenticollegati`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utenticollegati` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(250) DEFAULT NULL,
  `cognome` varchar(250) DEFAULT NULL,
  `ragione` varchar(255) NOT NULL DEFAULT '',
  `indirizzo` varchar(250) DEFAULT NULL,
  `citta` varchar(250) DEFAULT NULL,
  `provincia` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `telefono` varchar(250) DEFAULT NULL,
  `utente` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `tipo` varchar(255) NOT NULL DEFAULT '',
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `Id` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=162 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utenticollegati`
--

LOCK TABLES `utenticollegati` WRITE;
/*!40000 ALTER TABLE `utenticollegati` DISABLE KEYS */;
/*!40000 ALTER TABLE `utenticollegati` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'serenissima'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-09 14:21:20
